
SET NAMES utf8mb4;
SET time_zone = "+00:00";

CREATE TABLE IF NOT EXISTS students (
  student_id VARCHAR(50) PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  programa VARCHAR(100),
  cohorte VARCHAR(20),
  modalidad VARCHAR(50),
  campus VARCHAR(50),
  estado VARCHAR(20) DEFAULT 'activo'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS enrollments (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(50) NOT NULL,
  periodo VARCHAR(20) NOT NULL,
  curso_id VARCHAR(50) NOT NULL,
  creditos INT DEFAULT 0,
  estado VARCHAR(20) DEFAULT 'cursando',
  FOREIGN KEY (student_id) REFERENCES students(student_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS grades (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(50) NOT NULL,
  periodo VARCHAR(20) NOT NULL,
  curso_id VARCHAR(50) NOT NULL,
  calificacion DECIMAL(5,2),
  fecha DATE,
  INDEX ix_grades_student_period (student_id, periodo),
  FOREIGN KEY (student_id) REFERENCES students(student_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS attendance (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(50) NOT NULL,
  periodo VARCHAR(20) NOT NULL,
  curso_id VARCHAR(50) NOT NULL,
  fecha DATE NOT NULL,
  presente TINYINT(1) NOT NULL DEFAULT 1,
  INDEX ix_att_student_period (student_id, periodo),
  FOREIGN KEY (student_id) REFERENCES students(student_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS lms_events (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(50) NOT NULL,
  periodo VARCHAR(20) NOT NULL,
  evento VARCHAR(50) NOT NULL,
  fecha DATETIME NOT NULL,
  peso DECIMAL(10,4) DEFAULT 1.0,
  INDEX ix_lms_student_period (student_id, periodo),
  FOREIGN KEY (student_id) REFERENCES students(student_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS financials (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(50) NOT NULL,
  periodo VARCHAR(20) NOT NULL,
  estado_pago VARCHAR(30),
  dias_mora INT DEFAULT 0,
  FOREIGN KEY (student_id) REFERENCES students(student_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS interventions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(50) NOT NULL,
  periodo VARCHAR(20) NOT NULL,
  tipo VARCHAR(80) NOT NULL,
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  autor VARCHAR(50),
  resultado VARCHAR(50),
  notas TEXT,
  INDEX ix_int_student_period (student_id, periodo),
  FOREIGN KEY (student_id) REFERENCES students(student_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS risk_scores (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(50) NOT NULL,
  periodo VARCHAR(20) NOT NULL,
  score DOUBLE NOT NULL,
  nivel VARCHAR(10) NOT NULL,
  prioridad DOUBLE NOT NULL,
  razones_json JSON,
  model_version VARCHAR(50),
  scored_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX ix_risk_student_period (student_id, periodo),
  FOREIGN KEY (student_id) REFERENCES students(student_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS features_estudiante_periodo (
  student_id VARCHAR(50) NOT NULL,
  periodo VARCHAR(20) NOT NULL,
  prom_calif DOUBLE,
  reprobaciones INT,
  pct_asistencia DOUBLE,
  dias_activo_lms INT,
  entregas_tarde INT,
  dias_desde_ultima_actividad INT,
  dias_mora_prom DOUBLE,
  intervenciones_previas INT,
  creditos_en_curso INT,
  PRIMARY KEY (student_id, periodo),
  FOREIGN KEY (student_id) REFERENCES students(student_id)
) ENGINE=InnoDB;
