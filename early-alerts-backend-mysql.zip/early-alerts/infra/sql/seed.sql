
INSERT INTO students (student_id, nombre, programa, cohorte, modalidad, campus, estado) VALUES
('A001', 'Ana Torres', 'Ing. Sistemas', '2024-2', 'Presencial', 'Central', 'activo'),
('A002', 'Luis Pérez', 'Psicología', '2024-2', 'Virtual', 'Norte', 'activo');

INSERT INTO enrollments (student_id, periodo, curso_id, creditos, estado) VALUES
('A001', '2025-1', 'MAT101', 3, 'cursando'),
('A001', '2025-1', 'PROG201', 4, 'cursando'),
('A002', '2025-1', 'PSI110', 3, 'cursando');

INSERT INTO features_estudiante_periodo (student_id, periodo, prom_calif, reprobaciones, pct_asistencia, dias_activo_lms, entregas_tarde, dias_desde_ultima_actividad, dias_mora_prom, intervenciones_previas, creditos_en_curso) VALUES
('A001', '2025-1', 3.6, 0, 0.92, 12, 1, 3, 0, 0, 7),
('A002', '2025-1', 3.0, 1, 0.70, 5, 3, 14, 10, 1, 3);
