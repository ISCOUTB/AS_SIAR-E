// lib/main.dart
// Punto de entrada de la aplicación SIAR-E Flutter Web.

import 'package:flutter/material.dart';
import 'screens/dashboard_screen.dart';

void main() {
  runApp(const SiarEApp());
}

class SiarEApp extends StatelessWidget {
  const SiarEApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SIAR-E · Alertas Tempranas',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF185FA5),
          brightness: Brightness.light,
          surface: Colors.white,
          surfaceContainerHighest: const Color(0xFFF1EFE8),
        ),
        fontFamily: 'Roboto',
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            side: BorderSide(color: Colors.grey.shade300),
            foregroundColor: Colors.black87,
          ),
        ),
      ),
      home: const DashboardScreen(),
    );
  }
}
