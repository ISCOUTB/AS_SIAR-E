// lib/models/student_risk.dart
// Modelo de datos que representa un estudiante con su score de riesgo.
// Refleja exactamente los campos que devuelve el endpoint /dashboard/alerts

class StudentRisk {
  final String id;
  final String nombre;
  final String programa;
  final String? semestre;
  final String nivel; // "Alto", "Medio", "Bajo"
  final double score; // 0–100
  final double? asistencia; // porcentaje 0–100
  final double? notas; // promedio calificaciones
  final String? plataforma; // "Alta", "Media", "Baja", "Muy baja"
  final bool intervenido;

  const StudentRisk({
    required this.id,
    required this.nombre,
    required this.programa,
    this.semestre,
    required this.nivel,
    required this.score,
    this.asistencia,
    this.notas,
    this.plataforma,
    this.intervenido = false,
  });

  // Constructor desde JSON (respuesta del backend FastAPI)
  factory StudentRisk.fromJson(Map<String, dynamic> json) {
    return StudentRisk(
      id: json['id'] as String,
      nombre: json['nombre'] as String,
      programa: json['programa'] as String,
      semestre: json['semestre'] as String?,
      nivel: json['riesgo'] as String,
      score: (json['score'] as num).toDouble(),
      asistencia: json['asistencia'] != null
          ? (json['asistencia'] as num).toDouble()
          : null,
      notas:
          json['notas'] != null ? (json['notas'] as num).toDouble() : null,
      plataforma: json['plataforma'] as String?,
      intervenido: json['intervenido'] as bool? ?? false,
    );
  }

  // Nivel como enum para comparaciones
  NivelRiesgo get nivelEnum {
    switch (nivel.toLowerCase()) {
      case 'alto':
        return NivelRiesgo.alto;
      case 'medio':
        return NivelRiesgo.medio;
      default:
        return NivelRiesgo.bajo;
    }
  }
}

enum NivelRiesgo { alto, medio, bajo }

// ─── Datos sintéticos para modo demo (sin backend) ───────────────────────────
// Replica la misma lógica de ml/common.py del backend
List<StudentRisk> generarDatosSinteticos() {
  final programas = [
    'Ing. Sistemas',
    'Administración',
    'Psicología',
    'Contaduría',
    'Derecho',
  ];

  final nombres = [
    'Santiago Ramos',
    'Laura Gómez',
    'Daniel Martínez',
    'Valentina Torres',
    'Andrés Herrera',
    'Camila Vargas',
    'Juan Rodríguez',
    'Paola Jiménez',
    'Sergio Morales',
    'Ana Reyes',
    'Felipe Castro',
    'María López',
    'Carlos Pérez',
    'Isabella Ruiz',
    'Diego Sánchez',
    'Natalia Mendoza',
    'Tomás García',
    'Luisa Ramírez',
    'Sebastián Díaz',
    'Alejandra Cruz',
    'Mateo Álvarez',
    'Sara Ortiz',
    'David Muñoz',
    'Catalina Flores',
    'Julián Navarro',
  ];

  final List<StudentRisk> estudiantes = [];
  int idx = 0;

  // Valores fijos para reproducibilidad (sin dart:math random)
  final scoresSeed = [
    72.0, 65.0, 81.0, 45.0, 28.0,
    90.0, 38.0, 55.0, 19.0, 74.0,
    62.0, 33.0, 87.0, 22.0, 50.0,
    78.0, 41.0, 66.0, 15.0, 93.0,
    57.0, 30.0, 84.0, 47.0, 70.0,
  ];

  final asistencias = [
    58.0, 72.0, 45.0, 88.0, 95.0,
    30.0, 81.0, 63.0, 97.0, 52.0,
    67.0, 90.0, 38.0, 94.0, 75.0,
    48.0, 84.0, 61.0, 99.0, 25.0,
    70.0, 87.0, 42.0, 79.0, 55.0,
  ];

  for (final prog in programas) {
    for (int i = 0; i < 5; i++) {
      final score = scoresSeed[idx % scoresSeed.length];
      final nivel = score >= 60
          ? 'Alto'
          : score >= 30
              ? 'Medio'
              : 'Bajo';

      estudiantes.add(StudentRisk(
        id: 'EST-${(idx + 1).toString().padLeft(4, '0')}',
        nombre: nombres[idx % nombres.length],
        programa: prog,
        semestre: '${(idx % 4) + 1}',
        nivel: nivel,
        score: score,
        asistencia: asistencias[idx % asistencias.length],
        notas: 1.5 + (idx % 10) * 0.35,
        plataforma: score > 60 ? 'Baja' : score > 30 ? 'Media' : 'Alta',
        intervenido: idx % 7 == 0,
      ));
      idx++;
    }
  }

  // Ordenar por score descendente (prioridad)
  estudiantes.sort((a, b) => b.score.compareTo(a.score));
  return estudiantes;
}
