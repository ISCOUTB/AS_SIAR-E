// lib/screens/dashboard_screen.dart
// Pantalla principal. Orquesta todos los widgets del dashboard.

import 'package:flutter/material.dart';
import '../models/student_risk.dart';
import '../services/api_service.dart';
import '../widgets/metric_card.dart';
import '../widgets/risk_donut_chart.dart';
import '../widgets/program_bar_chart.dart';
import '../widgets/model_weights_card.dart';
import '../widgets/students_table.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<StudentRisk> _allData = [];
  List<StudentRisk> _filtered = [];
  bool _loading = true;
  String? _error;

  // Filtros
  String _selectedPrograma = '';
  String _selectedSemestre = '';
  String _periodo = '2026-1';

  final _programas = [
    '',
    'Ing. Sistemas',
    'Administración',
    'Psicología',
    'Contaduría',
    'Derecho',
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await ApiService.obtenerAlertas(periodo: _periodo);
      setState(() {
        _allData = data;
        _loading = false;
      });
      _applyFilters();
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  void _applyFilters() {
    setState(() {
      _filtered = _allData.where((s) {
        if (_selectedPrograma.isNotEmpty && s.programa != _selectedPrograma) {
          return false;
        }
        if (_selectedSemestre.isNotEmpty) {
          final sem = int.tryParse(_selectedSemestre) ?? 0;
          final sSem = int.tryParse(s.semestre ?? '0') ?? 0;
          if (sem == 4 && sSem < 4) return false;
          if (sem < 4 && sSem != sem) return false;
        }
        return true;
      }).toList();
    });
  }

  // ── KPIs ───────────────────────────────────────────────────────────────────
  int get _countAlto =>
      _filtered.where((s) => s.nivelEnum == NivelRiesgo.alto).length;
  int get _countMedio =>
      _filtered.where((s) => s.nivelEnum == NivelRiesgo.medio).length;
  int get _countBajo =>
      _filtered.where((s) => s.nivelEnum == NivelRiesgo.bajo).length;
  double get _avgScore => _filtered.isEmpty
      ? 0
      : _filtered.map((s) => s.score).reduce((a, b) => a + b) /
          _filtered.length;
  int get _tasaRiesgo => _filtered.isEmpty
      ? 0
      : ((_countAlto + _countMedio) / _filtered.length * 100).round();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F4F1),
      body: Column(
        children: [
          _buildTopBar(),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _error != null
                    ? _buildError()
                    : _buildBody(),
          ),
        ],
      ),
    );
  }

  // ── Top bar ────────────────────────────────────────────────────────────────
  Widget _buildTopBar() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
      child: Row(
        children: [
          // Título
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.warning_amber_rounded,
                      size: 18, color: Color(0xFFBA7517)),
                  const SizedBox(width: 8),
                  const Text(
                    'SIAR-E — Alertas Tempranas',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      'v2 · activo',
                      style: TextStyle(fontSize: 11, color: Colors.grey),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 2),
              Text(
                'Modelo predictivo de riesgo estudiantil · Período $_periodo',
                style:
                    TextStyle(fontSize: 12, color: Colors.grey.shade500),
              ),
            ],
          ),
          const Spacer(),

          // Filtro: programa
          _buildDropdown(
            value: _selectedPrograma,
            hint: 'Todos los programas',
            items: _programas,
            labels: const [
              'Todos los programas',
              'Ing. Sistemas',
              'Administración',
              'Psicología',
              'Contaduría',
              'Derecho',
            ],
            onChanged: (v) {
              setState(() => _selectedPrograma = v ?? '');
              _applyFilters();
            },
          ),
          const SizedBox(width: 8),

          // Filtro: semestre
          _buildDropdown(
            value: _selectedSemestre,
            hint: 'Todos los semestres',
            items: const ['', '1', '2', '3', '4'],
            labels: const [
              'Todos los semestres',
              'Semestre 1',
              'Semestre 2',
              'Semestre 3',
              'Semestre 4+',
            ],
            onChanged: (v) {
              setState(() => _selectedSemestre = v ?? '');
              _applyFilters();
            },
          ),
          const SizedBox(width: 8),

          // Botón recalcular
          OutlinedButton.icon(
            onPressed: _loadData,
            icon: const Icon(Icons.refresh, size: 16),
            label: const Text('Recalcular', style: TextStyle(fontSize: 13)),
            style: OutlinedButton.styleFrom(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDropdown({
    required String value,
    required String hint,
    required List<String> items,
    required List<String> labels,
    required ValueChanged<String?> onChanged,
  }) {
    return Container(
      height: 36,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          hint: Text(hint, style: const TextStyle(fontSize: 13)),
          style: const TextStyle(
              fontSize: 13, color: Colors.black87),
          items: List.generate(items.length, (i) {
            return DropdownMenuItem(
              value: items[i],
              child: Text(labels[i]),
            );
          }),
          onChanged: onChanged,
        ),
      ),
    );
  }

  // ── Cuerpo principal ───────────────────────────────────────────────────────
  Widget _buildBody() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ── KPI cards ────────────────────────────────────────────────────
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              SizedBox(
                width: 160,
                child: MetricCard(
                  label: 'Total estudiantes',
                  value: '${_filtered.length}',
                  valueColor: Colors.black87,
                  icon: Icons.people_outline,
                ),
              ),
              SizedBox(
                width: 160,
                child: MetricCard(
                  label: 'Riesgo alto',
                  value: '$_countAlto',
                  valueColor: const Color(0xFFA32D2D),
                  icon: Icons.warning_rounded,
                ),
              ),
              SizedBox(
                width: 160,
                child: MetricCard(
                  label: 'Riesgo medio',
                  value: '$_countMedio',
                  valueColor: const Color(0xFF854F0B),
                  icon: Icons.info_outline,
                ),
              ),
              SizedBox(
                width: 160,
                child: MetricCard(
                  label: 'Riesgo bajo',
                  value: '$_countBajo',
                  valueColor: const Color(0xFF0F6E56),
                  icon: Icons.check_circle_outline,
                ),
              ),
              SizedBox(
                width: 160,
                child: MetricCard(
                  label: 'Score promedio',
                  value: '${_avgScore.round()}%',
                  valueColor: Colors.black87,
                  icon: Icons.analytics_outlined,
                ),
              ),
              SizedBox(
                width: 160,
                child: MetricCard(
                  label: 'Tasa de riesgo',
                  value: '$_tasaRiesgo%',
                  valueColor: _tasaRiesgo > 50
                      ? const Color(0xFFA32D2D)
                      : const Color(0xFF854F0B),
                  icon: Icons.trending_up,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // ── Gráficas lado a lado ────────────────────────────────────────
          LayoutBuilder(builder: (context, constraints) {
            final isWide = constraints.maxWidth > 700;
            if (isWide) {
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: RiskDonutChart(data: _filtered)),
                  const SizedBox(width: 12),
                  Expanded(child: ProgramBarChart(data: _filtered)),
                ],
              );
            } else {
              return Column(
                children: [
                  RiskDonutChart(data: _filtered),
                  const SizedBox(height: 12),
                  ProgramBarChart(data: _filtered),
                ],
              );
            }
          }),
          const SizedBox(height: 16),

          // ── Pesos del modelo ────────────────────────────────────────────
          const ModelWeightsCard(),
          const SizedBox(height: 16),

          // ── Tabla priorizada ────────────────────────────────────────────
          StudentsTable(students: _filtered),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _buildError() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.error_outline, size: 48, color: Colors.red.shade300),
          const SizedBox(height: 12),
          Text(_error ?? 'Error desconocido'),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _loadData,
            child: const Text('Reintentar'),
          ),
        ],
      ),
    );
  }
}
