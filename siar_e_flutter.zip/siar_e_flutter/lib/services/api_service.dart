// lib/services/api_service.dart
// Servicio que se conecta al backend FastAPI (AS_SIAR-E).
// En modo demo usa datos sintéticos sin necesitar el backend corriendo.

import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/student_risk.dart';

class ApiService {
  // ── Cambia esta URL cuando tengas el backend corriendo ──────────────────────
  // Local:      http://localhost:8000
  // Docker:     http://localhost:8000
  // Producción: https://tu-dominio.com
  static const String baseUrl = 'http://localhost:8000';

  // Modo demo: usa datos locales sin llamar al backend
  // Cambia a false cuando el backend esté disponible
  static const bool modoDemo = true;

  /// Obtiene la lista de estudiantes con alertas para un período dado.
  /// Llama a GET /dashboard/alerts?periodo={periodo}&limit={limit}
  static Future<List<StudentRisk>> obtenerAlertas({
    String periodo = '2026-1',
    int limit = 100,
  }) async {
    if (modoDemo) {
      // Simula latencia de red
      await Future.delayed(const Duration(milliseconds: 600));
      return generarDatosSinteticos();
    }

    try {
      final uri = Uri.parse(
        '$baseUrl/dashboard/alerts?periodo=$periodo&limit=$limit',
      );
      final response = await http.get(
        uri,
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final List<dynamic> jsonList = jsonDecode(response.body);
        return jsonList
            .map((json) => StudentRisk.fromJson(json as Map<String, dynamic>))
            .toList();
      } else {
        throw Exception('Error del servidor: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('No se pudo conectar al backend: $e');
    }
  }

  /// Dispara el modelo predictivo para un período.
  /// Llama a POST /risk/predict
  static Future<void> ejecutarModelo({String periodo = '2026-1'}) async {
    if (modoDemo) {
      await Future.delayed(const Duration(milliseconds: 800));
      return;
    }

    final uri = Uri.parse('$baseUrl/risk/predict');
    await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'periodo': periodo}),
    );
  }
}
