// lib/widgets/risk_donut_chart.dart
// Gráfica de dona que muestra distribución Alto / Medio / Bajo.

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../models/student_risk.dart';

class RiskDonutChart extends StatelessWidget {
  final List<StudentRisk> data;

  const RiskDonutChart({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final alto = data.where((s) => s.nivelEnum == NivelRiesgo.alto).length;
    final medio = data.where((s) => s.nivelEnum == NivelRiesgo.medio).length;
    final bajo = data.where((s) => s.nivelEnum == NivelRiesgo.bajo).length;
    final total = data.length;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Distribución por nivel de riesgo',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w500,
              color: Colors.grey.shade600,
            ),
          ),
          const SizedBox(height: 12),
          // Leyenda
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _LegendItem(color: const Color(0xFFE24B4A), label: 'Alto ($alto)'),
              const SizedBox(width: 16),
              _LegendItem(color: const Color(0xFFBA7517), label: 'Medio ($medio)'),
              const SizedBox(width: 16),
              _LegendItem(color: const Color(0xFF639922), label: 'Bajo ($bajo)'),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 180,
            child: PieChart(
              PieChartData(
                sectionsSpace: 2,
                centerSpaceRadius: 50,
                sections: [
                  if (alto > 0)
                    PieChartSectionData(
                      value: alto.toDouble(),
                      color: const Color(0xFFE24B4A),
                      title: total > 0
                          ? '${(alto / total * 100).round()}%'
                          : '',
                      titleStyle: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                      radius: 55,
                    ),
                  if (medio > 0)
                    PieChartSectionData(
                      value: medio.toDouble(),
                      color: const Color(0xFFBA7517),
                      title: total > 0
                          ? '${(medio / total * 100).round()}%'
                          : '',
                      titleStyle: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                      radius: 55,
                    ),
                  if (bajo > 0)
                    PieChartSectionData(
                      value: bajo.toDouble(),
                      color: const Color(0xFF639922),
                      title: total > 0
                          ? '${(bajo / total * 100).round()}%'
                          : '',
                      titleStyle: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                      radius: 55,
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _LegendItem extends StatelessWidget {
  final Color color;
  final String label;

  const _LegendItem({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(fontSize: 11)),
      ],
    );
  }
}
