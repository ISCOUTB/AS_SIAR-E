// lib/widgets/model_weights_card.dart
// Visualiza los pesos del modelo analítico (ml/common.py).
// Permite transparencia y trazabilidad para consejeros académicos.

import 'package:flutter/material.dart';

class ModelWeightsCard extends StatelessWidget {
  const ModelWeightsCard({super.key});

  static const _weights = [
    _WeightItem('Baja asistencia', 0.25, Color(0xFFE24B4A)),
    _WeightItem('Bajo promedio académico', 0.20, Color(0xFFD4537E)),
    _WeightItem('Inactividad en plataforma', 0.20, Color(0xFFD85A30)),
    _WeightItem('Bajo uso LMS', 0.15, Color(0xFFBA7517)),
    _WeightItem('Entregas tardías', 0.10, Color(0xFF185FA5)),
    _WeightItem('Reprobaciones', 0.05, Color(0xFF534AB7)),
    _WeightItem('Riesgo financiero', 0.05, Color(0xFF888780)),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.tune, size: 15, color: Colors.grey.shade600),
              const SizedBox(width: 6),
              Text(
                'Pesos del modelo analítico (ml/common.py)',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey.shade600,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text(
                  'v2 · activo',
                  style: TextStyle(fontSize: 10, color: Colors.grey),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          ..._weights.map((w) => _WeightRow(item: w)),
        ],
      ),
    );
  }
}

class _WeightRow extends StatelessWidget {
  final _WeightItem item;

  const _WeightRow({required this.item});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          SizedBox(
            width: 190,
            child: Text(
              item.label,
              style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
            ),
          ),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: LinearProgressIndicator(
                value: item.weight,
                backgroundColor: Colors.grey.shade200,
                valueColor: AlwaysStoppedAnimation<Color>(item.color),
                minHeight: 6,
              ),
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: 32,
            child: Text(
              '${(item.weight * 100).round()}%',
              textAlign: TextAlign.right,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _WeightItem {
  final String label;
  final double weight;
  final Color color;

  const _WeightItem(this.label, this.weight, this.color);
}
