// lib/widgets/students_table.dart
// Tabla con scroll que lista los estudiantes ordenados por prioridad de riesgo.

import 'package:flutter/material.dart';
import '../models/student_risk.dart';

class StudentsTable extends StatefulWidget {
  final List<StudentRisk> students;

  const StudentsTable({super.key, required this.students});

  @override
  State<StudentsTable> createState() => _StudentsTableState();
}

class _StudentsTableState extends State<StudentsTable> {
  NivelRiesgo? _filterNivel; // null = todos

  List<StudentRisk> get _filtered {
    if (_filterNivel == null) return widget.students;
    return widget.students
        .where((s) => s.nivelEnum == _filterNivel)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;

    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Encabezado con filtros ──────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Row(
              children: [
                Icon(Icons.list_alt, size: 15, color: Colors.grey.shade600),
                const SizedBox(width: 6),
                Text(
                  'Listado priorizado · ${filtered.length} estudiantes',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey.shade600,
                  ),
                ),
                const Spacer(),
                _FilterChip(
                  label: 'Todos',
                  active: _filterNivel == null,
                  activeColor: Colors.grey.shade300,
                  textColor: Colors.black87,
                  onTap: () => setState(() => _filterNivel = null),
                ),
                const SizedBox(width: 6),
                _FilterChip(
                  label: 'Alto',
                  active: _filterNivel == NivelRiesgo.alto,
                  activeColor: const Color(0xFFF7C1C1),
                  textColor: const Color(0xFF791F1F),
                  onTap: () => setState(() => _filterNivel = NivelRiesgo.alto),
                ),
                const SizedBox(width: 6),
                _FilterChip(
                  label: 'Medio',
                  active: _filterNivel == NivelRiesgo.medio,
                  activeColor: const Color(0xFFFAEEDA),
                  textColor: const Color(0xFF633806),
                  onTap: () => setState(() => _filterNivel = NivelRiesgo.medio),
                ),
                const SizedBox(width: 6),
                _FilterChip(
                  label: 'Bajo',
                  active: _filterNivel == NivelRiesgo.bajo,
                  activeColor: const Color(0xFFEAF3DE),
                  textColor: const Color(0xFF3B6D11),
                  onTap: () => setState(() => _filterNivel = NivelRiesgo.bajo),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),

          // ── Tabla con scroll horizontal ─────────────────────────────────────
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columnSpacing: 16,
              headingRowHeight: 36,
              dataRowMinHeight: 44,
              dataRowMaxHeight: 56,
              headingTextStyle: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w500,
                color: Colors.grey.shade500,
              ),
              columns: const [
                DataColumn(label: Text('#')),
                DataColumn(label: Text('ID')),
                DataColumn(label: Text('Nombre')),
                DataColumn(label: Text('Programa')),
                DataColumn(label: Text('Score'), numeric: true),
                DataColumn(label: Text('Nivel')),
                DataColumn(label: Text('Asistencia'), numeric: true),
                DataColumn(label: Text('Promedio'), numeric: true),
                DataColumn(label: Text('LMS')),
              ],
              rows: List.generate(filtered.length, (i) {
                final s = filtered[i];
                return DataRow(
                  cells: [
                    // Posición / ranking
                    DataCell(_RankBadge(rank: i + 1)),

                    // ID
                    DataCell(Text(
                      s.id,
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.grey.shade500,
                      ),
                    )),

                    // Nombre
                    DataCell(Text(
                      s.nombre,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    )),

                    // Programa
                    DataCell(Text(
                      s.programa,
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.grey.shade600,
                      ),
                    )),

                    // Score con barra
                    DataCell(_ScoreBar(score: s.score, nivel: s.nivelEnum)),

                    // Nivel pill
                    DataCell(_NivelPill(nivel: s.nivelEnum)),

                    // Asistencia
                    DataCell(Text(
                      s.asistencia != null
                          ? '${s.asistencia!.round()}%'
                          : '—',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: _asistenciaColor(s.asistencia),
                      ),
                    )),

                    // Notas
                    DataCell(Text(
                      s.notas != null ? s.notas!.toStringAsFixed(1) : '—',
                      style: const TextStyle(fontSize: 12),
                    )),

                    // LMS
                    DataCell(Text(
                      s.plataforma ?? '—',
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.grey.shade600,
                      ),
                    )),
                  ],
                );
              }),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Color _asistenciaColor(double? asist) {
    if (asist == null) return Colors.grey;
    if (asist < 60) return const Color(0xFFA32D2D);
    if (asist < 80) return const Color(0xFF854F0B);
    return const Color(0xFF0F6E56);
  }
}

// ─── Subwidgets ───────────────────────────────────────────────────────────────

class _FilterChip extends StatelessWidget {
  final String label;
  final bool active;
  final Color activeColor;
  final Color textColor;
  final VoidCallback onTap;

  const _FilterChip({
    required this.label,
    required this.active,
    required this.activeColor,
    required this.textColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: active ? activeColor : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: active ? activeColor : Colors.grey.shade300,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            color: active ? textColor : Colors.grey.shade500,
          ),
        ),
      ),
    );
  }
}

class _RankBadge extends StatelessWidget {
  final int rank;

  const _RankBadge({required this.rank});

  @override
  Widget build(BuildContext context) {
    Color bg;
    Color fg;
    if (rank == 1) {
      bg = const Color(0xFFF7C1C1);
      fg = const Color(0xFF791F1F);
    } else if (rank <= 3) {
      bg = const Color(0xFFFAEEDA);
      fg = const Color(0xFF633806);
    } else {
      bg = Colors.grey.shade100;
      fg = Colors.grey.shade600;
    }

    return Container(
      width: 24,
      height: 24,
      decoration: BoxDecoration(color: bg, shape: BoxShape.circle),
      alignment: Alignment.center,
      child: Text(
        '$rank',
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w600,
          color: fg,
        ),
      ),
    );
  }
}

class _ScoreBar extends StatelessWidget {
  final double score;
  final NivelRiesgo nivel;

  const _ScoreBar({required this.score, required this.nivel});

  Color get _color {
    switch (nivel) {
      case NivelRiesgo.alto:
        return const Color(0xFFE24B4A);
      case NivelRiesgo.medio:
        return const Color(0xFFBA7517);
      case NivelRiesgo.bajo:
        return const Color(0xFF639922);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 48,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: score / 100,
              backgroundColor: Colors.grey.shade200,
              valueColor: AlwaysStoppedAnimation<Color>(_color),
              minHeight: 5,
            ),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          '${score.round()}%',
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: _color,
          ),
        ),
      ],
    );
  }
}

class _NivelPill extends StatelessWidget {
  final NivelRiesgo nivel;

  const _NivelPill({required this.nivel});

  @override
  Widget build(BuildContext context) {
    late Color bg;
    late Color fg;
    late String text;

    switch (nivel) {
      case NivelRiesgo.alto:
        bg = const Color(0xFFFCEBEB);
        fg = const Color(0xFFA32D2D);
        text = 'ALTO';
      case NivelRiesgo.medio:
        bg = const Color(0xFFFAEEDA);
        fg = const Color(0xFF854F0B);
        text = 'MEDIO';
      case NivelRiesgo.bajo:
        bg = const Color(0xFFEAF3DE);
        fg = const Color(0xFF3B6D11);
        text = 'BAJO';
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w600,
          color: fg,
        ),
      ),
    );
  }
}
