// lib/widgets/program_bar_chart.dart
// Barras con score promedio de riesgo por programa académico.

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../models/student_risk.dart';

class ProgramBarChart extends StatelessWidget {
  final List<StudentRisk> data;

  const ProgramBarChart({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    // Calcular score promedio por programa
    final Map<String, List<double>> byProg = {};
    for (final s in data) {
      byProg.putIfAbsent(s.programa, () => []).add(s.score);
    }

    final programas = byProg.keys.toList();
    final promedios = programas.map((p) {
      final scores = byProg[p]!;
      return scores.reduce((a, b) => a + b) / scores.length;
    }).toList();

    Color barColor(double score) {
      if (score >= 60) return const Color(0xFFE24B4A);
      if (score >= 30) return const Color(0xFFBA7517);
      return const Color(0xFF639922);
    }

    // Etiquetas cortas
    String shortLabel(String prog) {
      if (prog.length <= 10) return prog;
      return '${prog.substring(0, 9)}…';
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Score promedio por programa',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w500,
              color: Colors.grey.shade600,
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 180,
            child: BarChart(
              BarChartData(
                maxY: 100,
                minY: 0,
                barTouchData: BarTouchData(
                  touchTooltipData: BarTouchTooltipData(
                    getTooltipItem: (group, groupIndex, rod, rodIndex) {
                      return BarTooltipItem(
                        '${programas[groupIndex]}\n${rod.toY.round()}%',
                        const TextStyle(color: Colors.white, fontSize: 12),
                      );
                    },
                  ),
                ),
                titlesData: FlTitlesData(
                  show: true,
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        final i = value.toInt();
                        if (i >= 0 && i < programas.length) {
                          return Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              shortLabel(programas[i]),
                              style: const TextStyle(fontSize: 9),
                              textAlign: TextAlign.center,
                            ),
                          );
                        }
                        return const SizedBox();
                      },
                      reservedSize: 32,
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 32,
                      getTitlesWidget: (value, meta) {
                        if (value % 25 == 0) {
                          return Text(
                            '${value.toInt()}%',
                            style: const TextStyle(fontSize: 10),
                          );
                        }
                        return const SizedBox();
                      },
                    ),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: 25,
                  getDrawingHorizontalLine: (value) => FlLine(
                    color: Colors.grey.shade200,
                    strokeWidth: 0.8,
                  ),
                ),
                borderData: FlBorderData(show: false),
                barGroups: List.generate(programas.length, (i) {
                  return BarChartGroupData(
                    x: i,
                    barRods: [
                      BarChartRodData(
                        toY: promedios[i],
                        color: barColor(promedios[i]),
                        width: 24,
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(4),
                        ),
                      ),
                    ],
                  );
                }),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
