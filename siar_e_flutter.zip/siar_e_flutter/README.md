# SIAR-E Dashboard — Flutter Web

Dashboard de alertas tempranas para retención estudiantil.
Se conecta al backend FastAPI del proyecto AS_SIAR-E.

---

## Requisitos previos

1. Instalar Flutter SDK (https://docs.flutter.dev/get-started/install)
2. Verificar instalación:
   ```bash
   flutter doctor
   ```
3. Habilitar soporte web (solo la primera vez):
   ```bash
   flutter config --enable-web
   ```

---

## Cómo correr el proyecto

### Paso 1 — Ir a la carpeta del proyecto
```bash
cd siar_e_flutter
```

### Paso 2 — Instalar dependencias
```bash
flutter pub get
```

### Paso 3 — Correr en el navegador (modo demo, sin backend)
```bash
flutter run -d chrome
```

El dashboard abre en Chrome con datos sintéticos que replican
el modelo de ml/common.py del backend.

---

## Conectar al backend real (FastAPI)

Cuando tengas el backend corriendo (`uvicorn app.main:app --reload`):

1. Abre `lib/services/api_service.dart`
2. Cambia la línea:
   ```dart
   static const bool modoDemo = true;
   ```
   por:
   ```dart
   static const bool modoDemo = false;
   ```
3. Asegúrate de que `baseUrl` apunte a tu backend:
   ```dart
   static const String baseUrl = 'http://localhost:8000';
   ```
4. Guarda y la app se recarga automáticamente.

---

## Compilar para producción (deploy)

```bash
flutter build web --release
```

Los archivos quedan en `build/web/`. Puedes servirlos con cualquier
servidor estático (Nginx, Apache, Firebase Hosting, etc.).

---

## Estructura del proyecto

```
lib/
├── main.dart                    ← Punto de entrada
├── models/
│   └── student_risk.dart        ← Modelo de datos + datos sintéticos
├── services/
│   └── api_service.dart         ← HTTP client → FastAPI
├── screens/
│   └── dashboard_screen.dart    ← Pantalla principal
└── widgets/
    ├── metric_card.dart          ← Tarjeta KPI
    ├── risk_donut_chart.dart     ← Gráfica dona (distribución)
    ├── program_bar_chart.dart    ← Barras por programa
    ├── model_weights_card.dart   ← Pesos del modelo ML
    └── students_table.dart       ← Tabla priorizada con filtros
```

---

## Dependencias principales

| Paquete     | Uso                              |
|-------------|----------------------------------|
| fl_chart    | Gráficas de dona y barras        |
| http        | Llamadas al backend FastAPI      |
| intl        | Formato de números y fechas      |
| flutter_svg | Íconos SVG opcionales            |

---

## Endpoints del backend que usa el dashboard

| Método | Endpoint                        | Descripción                    |
|--------|---------------------------------|--------------------------------|
| GET    | /dashboard/alerts?periodo=...   | Lista priorizada de estudiantes|
| POST   | /risk/predict                   | Ejecutar modelo predictivo     |
| GET    | /risk/alerts/{periodo}          | Alertas crudas del modelo      |
